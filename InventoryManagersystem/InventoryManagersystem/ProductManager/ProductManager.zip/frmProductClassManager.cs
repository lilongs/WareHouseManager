﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using BULayer;

namespace InventoryManagersystem.ProductManager
{
    public partial class frmProductClassManager : Form
    {
        BUProductManagerResult MyPms = new BUProductManagerResult();
        public frmProductClassManager()
        {
            InitializeComponent(); // 1
        }

        private void brnSearch_Click(object sender, EventArgs e)
        {
            string paramProductClassName = this.txtBoxProductName.Text.ToString();
            string paramProductClassCode = this.txtBoxProductCode.Text.ToString();
            bool isNotNull = MyPms.CheckProductClass(paramProductClassName,paramProductClassCode);
            if (isNotNull)
            {
                this.dvgData.DataSource = MyPms.GetProductClassTbl(paramProductClassName, paramProductClassCode);
            }
            else
            {
                MessageBox.Show("查无记录");
            }

        }

        private void btnModify_Click(object sender, EventArgs e)
        {
            int count = this.dvgData.SelectedRows.Count;
            if (count == 0)
            {
                MessageBox.Show("请先搜索/刷新并选择需要修改的用户行", "错误！", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            string paramClassName = this.dvgData.SelectedRows[0].Cells["ProductClassName"].Value.ToString();
            string paramRemark = this.dvgData.SelectedRows[0].Cells["Remark"].Value.ToString();
            int paramClassCode = Convert.ToInt32(this.dvgData.SelectedRows[0].Cells["ProductClassID"].Value);
            string paramEmployeeName= this.Tag.ToString();

            frmProductClassModify myfrmClassAdd = new frmProductClassModify(paramClassName, paramRemark, paramClassCode, paramEmployeeName);
            if (myfrmClassAdd.ShowDialog() == DialogResult.Yes)
            {
                brnSearch_Click(sender, e);
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            

            frmClassAdd myfrmClassAdd = new frmClassAdd();
            myfrmClassAdd.Tag = this.Tag.ToString();
            DialogResult dr = myfrmClassAdd.ShowDialog();
            if (dr == DialogResult.OK)
            {
                brnSearch_Click(sender, e);
            }
        }

        private void frmProductClassManager_Load(object sender, EventArgs e)
        {
            brnSearch_Click(sender,e);
        }

        private void btnDel_Click(object sender, EventArgs e)
        {
             if (this.dvgData.RowCount == 0)
            {
                MessageBox.Show("请选择要删除的用户！");
                return;
            }
            int count = this.dvgData.SelectedRows.Count;
            BUProductManagerResult MyPMR = new BUProductManagerResult();
            bool ReturnValue = false;
            DialogResult dr = MessageBox.Show("确定删除此条信息吗？", "温馨提示", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
            if (dr == DialogResult.OK)
            {
                for (int i = 0; i < count; i++)
                {
                    string paramClassValue = this.dvgData.SelectedRows[i].Cells["ProductClassID"].Value.ToString();
                    ReturnValue = MyPMR.DelClassData(paramClassValue);
                }
                if (ReturnValue)
                {
                    MessageBox.Show("恭喜您，删除数据成功！", "恭喜", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    brnSearch_Click(sender, e);

                }
                else
                {
                    MessageBox.Show("操作错误", "错误提示", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
    }
}
